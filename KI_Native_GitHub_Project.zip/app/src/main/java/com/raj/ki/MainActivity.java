package com.raj.ki;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setText("K.I");
        t.setTextSize(40);
        t.setGravity(17);
        setContentView(t);
    }
}
