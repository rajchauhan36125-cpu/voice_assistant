plugins { id("com.android.application") }
android {
    namespace = "com.raj.ki"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.raj.ki"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
