# K.I

Minimal native Android app. It only displays K.I.
